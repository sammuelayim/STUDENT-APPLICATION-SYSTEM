package com.example.studentapplicationsystem.model;

public class Login {
    private int loginId;
    private String serial;
    private Integer pin;

    public Login() {
    }

    public Login(String serial, Integer pin) {
        this.serial = serial;
        this.pin = pin;
    }

    public int getLoginId() {
        return loginId;
    }

    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public Integer getPin() {
        return pin;
    }

    public void setPin(Integer pin) {
        this.pin = pin;
    }
}
