module com.example.studentapplicationsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.studentapplicationsystem to javafx.fxml;
    exports com.example.studentapplicationsystem;
}